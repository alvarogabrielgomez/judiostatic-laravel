<?php $__env->startSection('title', __('UILogin.register')); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.min.css')); ?>">

<header id="header" class="header-register">
        <div id="header-container-nomargin" class="animated fadeIn">
          <nav id="header-logo">
            <ul>
              <!-- <li id="header-logo-img"><a href="#"><img src="" alt=""></a></li> -->
              <li id=""><div id="header-logo-container-register" class="animated fadeIn hero-logo"></div></li>
            </ul>
          </nav>
        </div>          
      </header><!--Final de contenedor header-->


<div class="container">
        <div class="row" style="height: 657px;">
            <div id="main-hero-img" class="animated fadeIn">
                <div id="main-hero-register" class="animated fadeIn">
                    <div class="main-hero-img-register-textcontainer register-info-box">
                        <p id="textbloq1" style="text-align: left;"><?php echo e(__('messages.h1_msg_hero')); ?></p> 
                        <p id="textbloq2" style="margin-bottom: 39px;text-align: left;">
                                <?php echo e(__('messages.p_msg_hero')); ?><br>
                        </p> 
                        <a href="/login" class="herob button blue" style = "margin:0px;width: 180px;"><?php echo e(__('UILogin.login')); ?></a> 
                        <a href="#main"><div id="main-hero-arrow"></div></a>
                    </div>
                    <div class="main-hero-img-register-textcontainer register-box">
                        <form method="POST" action="/registering" class="register-form-box" id="register-from">
                            <?php echo csrf_field(); ?>    
                            <div id="loading-overlay" style="top: 0px;left: 0px;opacity: 0;display:none;">
                                    <div class="loader-small-container">
                                        <div class="loader-small"><?php echo e(__('messages.loading')); ?>...</div>
                                    </div>
                                </div>

                                <div id="nav-bar" class="light-bar-t" style="position: absolute; top: 11px; left:0px; margin-top: 0px !important; z-index: 1000;"><div id="nav-bar-container"><nav><ul class="light-bar-text"><li><a href="/"><div id="home-icon"></div></a></li> <li class="navbar-divisor">&gt;</li> <li><?php echo e(__('UILogin.register')); ?></li></ul></nav></div></div>
                                <div id="logo-form-register" style=""><div class="lefty-trans-black-logo-form"></div></div>
                                <div class="leyenda-registrar">
                                <h2 style="margin-bottom: 13px;"><strong><?php echo e(__('UILogin.register_h1')); ?></strong></h2>
                                <p style="margin: 0px;"><?php echo e(__('UILogin.register_p')); ?></p>
                                </div>

                                <div class="form-container-view">
                                <div style="margin-top: 63px;justify-content:left;" class="container-input-2col">
                                    <div class="group-input group-row material-sm">
                                            <input class="input-material<?php echo e($errors->has('name') ? ' invalid-data' : ''); ?>" id="client_first" type="text" name="client_first" value="<?php echo e(old('name')); ?>" required autofocus>
                                            <span class="highlight"></span>
                                            <span class="bar"></span>
                                            <label class="label-material"><?php echo e(__('UILogin.name')); ?></label>

                                            <?php if($errors->has('name')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                            </span>
                                        <?php endif; ?>

                                    </div>
                                    <div class="group-input group-row material-sm">
                                            <input class="input-material" id="client_last" type="text" name="client_last" required>
                                            <span class="highlight"></span>
                                            <span class="bar"></span>
                                            <label class="label-material"><?php echo e(__('UILogin.last_name')); ?></label>
                                    </div>
                                    <br>
                                </div>

                                <div class="group-input group-centrado material-sm">
                                        <input style="width: 91.5%;max-width: 471px;" class="input-material<?php echo e($errors->has('email') ? ' invalid-data' : ''); ?>" id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required>
                                        <span class="highlight"></span>
                                        <span class="bar"></span>
                                        <label class="label-material"><?php echo e(__('UILogin.email')); ?></label>

                                        <?php if($errors->has('email')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                        <?php endif; ?>


                                </div>
                                <br>
                                <div style="justify-content:left;" class="container-input-2col" style="margin-top: -6px;">
                                <div class="group-input group-row material-sm">
                                        <input class="input-material<?php echo e($errors->has('password') ? ' invalid-data' : ''); ?>" id="password" type="password" name="password" required>
                                        <span class="highlight"></span>
                                        <span class="bar"></span>
                                        <label class="label-material"><?php echo e(__('UILogin.password')); ?></label>

                                        <?php if($errors->has('password')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('password')); ?></strong>
                                        </span>
                                    <?php endif; ?>


                                </div>
                                <div class="group-input group-row material-sm">
                                        <input class="input-material" id="password_confirmation" type="password" name="password_confirmation" required>
                                        <span class="highlight"></span>
                                        <span class="bar"></span>
                                        <label class="label-material"><?php echo e(__('UILogin.confirm')); ?></label>
                                    </div>
                                </div>
                                <label style="font-size: 0.8em;width: 300px;display: block;"><?php echo e(__('UILogin.password_requirements')); ?></label>
                            <br>
                            </div>
                            <button form="register-from" type="submit" name="register-submit" class="button red register-submit"><?php echo e(__('pagination.next')); ?></button>
                        
                        
                        
                        </form>
                           
                    </div>
                </div>

                


            </div>
        </div>
</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.loginapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\judiostatic-laravel\resources\views/auth/register.blade.php ENDPATH**/ ?>