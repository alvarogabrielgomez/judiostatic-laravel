<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <meta name="viewport" content="width=320, initial-scale=0.86, maximum-scale=0.86, minimum-scale=0.86"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Omeleth Cupon - Cupons online baratos e rápidos.</title>
     <!-- Scripts -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"type="text/javascript" charset="utf-8"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <META NAME="Title" CONTENT="Omeleth Cupon - Cupons online baratos e rápidos.">
    <META NAME="Keywords" CONTENT="Cupon, Barato, Gourmet, Online, Rapido, Prazer">
    <META NAME="Subject" CONTENT="Cupon Business">
    <META NAME="Language" CONTENT="Portuguese">
    <meta property="og:url"                content="https://omeleth.com" />
    <meta property="og:type"               content="website" />
    <meta property="og:title"              content="Omeleth Cupon" />
    <meta property="og:description"        content="Conte conosco para resolver o seu dia, e você pode dar o seu prazer quando quiser. Cupons online baratos e rápidos." />
    <meta property="og:image"              content="https://omeleth.com/<?php echo e(asset('images/omeleth_red_image.png')); ?>" />
    <meta property="fb:app_id"             content="238563567095772" />

    <link rel="preload" href="<?php echo e(asset('images/icons/main-box-loading.svg')); ?>" as="image">

    
    <link rel="preload" href="<?php echo e(asset('css/app.css')); ?>" as= "style">

    <link rel="preload" href="<?php echo e(asset('images/hero/hero-img-mobile.jpg')); ?>" as="image"  media="(max-width: 799px)">
    <link rel="preload" href="<?php echo e(asset('images/hero/hero-img.jpg')); ?>" as="image"  media="(min-width: 800px)">
    <link rel="preload" href="<?php echo e(asset('slick/slick-theme.css')); ?>" as= "style">
    <link rel="preload" href="<?php echo e(asset('slick/slick.css')); ?>" as= "style">
    <link rel="preload" href="<?php echo e(asset('images/Empty-State2.svg')); ?>" as= "image">
    
    
    <link rel="preload" href="<?php echo e(asset('/slick/slick.min.js')); ?>" as="script">

    <link rel="apple-touch-icon" sizes="60x60" href="<?php echo e(asset('images/favicon/apple-touch-icon-60x60.png')); ?>">
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('images/favicon/apple-touch-icon-76x76.png')); ?>">
    <link rel="apple-touch-icon" sizes="120x120" href="<?php echo e(asset('images/favicon/apple-touch-icon-120x120.png')); ?>">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo e(asset('images/favicon/apple-touch-icon-152x152.png')); ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('images/favicon/apple-touch-icon-180x180.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('images/favicon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('images/favicon/site.webmanifest')); ?>">
    
    <link rel="mask-icon" href="<?php echo e(asset('images/favicon/safari-pinned-tab.svg')); ?>" color="#bc2b19">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#bc2b19">

    

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>"/>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick/slick.css')); ?>"/>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('slick/slick-theme.css')); ?>"/>
    
    <script src="<?php echo e(asset('slick/slick.min.js')); ?>"></script>
  
    <link href="https://fonts.googleapis.com/css?family=Oxygen:400,700" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/regular.css" integrity="sha384-l+NpTtA08hNNeMp0aMBg/cqPh507w3OvQSRoGnHcVoDCS9OtgxqgR7u8mLQv8poF" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/solid.css" integrity="sha384-aj0h5DVQ8jfwc8DA7JiM+Dysv7z+qYrFYZR+Qd/TwnmpDI6UaB3GJRRTdY8jYGS4" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/fontawesome.css" integrity="sha384-WK8BzK0mpgOdhCxq86nInFqSWLzR5UAsNg0MGX9aDaIIrFWQ38dGdhwnNCAoXFxL" crossorigin="anonymous"> 
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.min.css')); ?>">
</head>
<body>
  <script>
      window.default_locale = "<?php echo e(config('app.locale')); ?>";
      window.fallback_locale = "<?php echo e(config('app.fallback_locale')); ?>";
      window.messages = <?php echo json_encode($messages, 15, 512) ?>;
    </script>
    <?php if(session('status')): ?>
    <script>
      function alertSession(){
        custom.msg('<?php echo e(session('status')); ?>', 5000);
      };
        </script>
      <?php endif; ?>

    <div id="app">
    <div id="themoderfoquer">

        <div class="shadow"  id="toastdiv">
          <div class="toastprogressbar"></div>
            <label class="title" for="titles">Title</label>
            <label class="content" for="Content">Lorem ipsum dolor sit amet</label>
        </div>
    

        <header id="header" class="index-h">
            <div id="header-container">
              <nav id="header-logo">
                <ul>
                  <!-- <li id="header-logo-img"><a href="#"><img src="" alt=""></a></li> -->
                  <li id=""><div id="header-logo-container" class="hero-logo"></div></li>
                </ul>
              </nav>
              <div id="header-container-menu">
                <nav id="header-menu">
                  <ul id="header-menu-buttoms">
                    <li><a href="index.php"><?php echo e(__('messages.home')); ?></a></li>

                  
                    <li class="login-status">
               
                      <?php echo $__env->make('partials.loginstatus', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     
                  </li> 
                  </ul>
                </nav>
              </div>
            </div>          
          </header><!--Final de contenedor header-->
          
    <?php echo $__env->yieldContent('content'); ?>
    </div>
  </div>

  <script>
      
       function dropdownShow() {
            document.getElementById("dropdown-menu").classList.toggle("show");
        }
    
      var isMobile;
      function widthpx() {
        if ($(document).width() <= 800) {
          isMobile = true;
          $("#onload-carousel").css("background-position", "center");
        } else if ($(document).width() >= 801) {
          isMobile = false;
          $("#onload-carousel").css("background-position", "left");
        }
      }
      widthpx();
      window.onload = function() {
        window.addEventListener("resize", widthpx);
      };
      </script>

    <footer id="footer">
            <div id="ir-arriba"><a href="#"><?php echo e(__('messages.up')); ?></a></div>
          
            <div class="f-container">
              <div class="b1">
                <div class="navFooterHeader"><?php echo e(__('messages.footer_col1_h1')); ?></div>
                <ul class="navFooter">
                  <li class="">
                    <a href="" class=""><?php echo e(__('messages.jobs')); ?></a>
                  </li>
                  <li>
                    <a href="" class=""><?php echo e(__('messages.blog')); ?></a>
                  </li>
                  <li>
                    <a href="" class=""><?php echo e(__('messages.about_omeleth')); ?></a>
                  </li>
                </ul>
              </div>
          
              <div class="b2">
                <div class="navFooterHeader"><?php echo e(__('messages.footer_col2_h1')); ?></div>
                <ul class="navFooter">
                  <li class="">
                    <a href="documents/with-us.html" class=""><?php echo e(__('messages.sell_with_os_in_omeleth')); ?></a>
                  </li>
                  <li>
                    <a href="documents/lets-start.html" class=""><?php echo e(__('messages.how_start')); ?></a>
                  </li>
                </ul>
              </div>
          
              <div class="b3">
                <div class="navFooterHeader"><?php echo e(__('messages.footer_col3_h1')); ?></div>
                <ul class="navFooter">
                  <li class="">
                    <a href="" class=""><?php echo e(__('messages.your_account')); ?></a>
                  </li>
                  <li>
                    <a href="" class=""><?php echo e(__('messages.tell_errors')); ?></a>
                  </li>
                  <li>
                    <a href="" class=""><?php echo e(__('messages.contr_sugg')); ?></a>
                  </li>
                </ul>
              </div>
            </div>
            <div id="creditos"><div class="logo-creditos"></div></div>
          
            <div id="creditos">
              <div>
                <a href="/documents/es/terms"><?php echo e(__('messages.terms')); ?></a>
                <a href="/documents/es/privacy-policy"><?php echo e(__('messages.privacy')); ?></a
                ><a href="https://ckj.one" rel="external"> © Alvaro Gabriel Gomez</a>.
                <?php echo e(__('messages.rights')); ?>

              </div>
            </div>
          </footer>

          
          <script src="<?php echo e(asset('js/custom.js')); ?>" defer></script>
          <?php if(session('status')): ?>
          <script>
          document.addEventListener("DOMContentLoaded", function(event) { 
            setTimeout(() => {
            alertSession();
            }, 200);
          });
          </script>
          <?php endif; ?>
</body>
</html>

<?php /**PATH C:\Users\user\judiostatic-laravel\resources\views/layouts/appindex.blade.php ENDPATH**/ ?>