<?php $__env->startSection('title', 'TODOS'); ?>
<?php $__env->startSection('content'); ?>


<div id="nav-bar">
        <div id="nav-bar-container">
                    <nav>
                        <ul>
                            <li><a href="/"><div id="home-icon"></div></a></li>
                            <li class="navbar-divisor">&gt;</li>
                            <li><a href="/deals" style="margin:0;padding:0;"><?php echo e(__('messages.deals')); ?></a></li>
                            
                        </ul>
                    </nav>
        </div>
        </div>

<section>

     <div id="app">
     
    <div id="main-container"style = "margin-top:0px;">
        <div id="main">
            <div id="main-items">
                
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a href="/deals/<?php echo e($post->post_id); ?>" class="main-box">

                        <div class="main-img">
                            <img src="<?php echo e(asset($post->post_hero_img_url)); ?>" alt="">
                        </div>
                    
                        <div class="buss-name"><span><?php echo e($post->buss_name); ?></span></div>
                        <clock-sm style="
                        float: right;
                        margin-top: -30px;
                        margin-bottom: -8px;" 
                        post_created_at="<?php echo e($post->created_at); ?>" post_offer_end_at="<?php echo e($post->offer_end_at); ?>" realtime = "false" small="true"></clock-sm>
                    
                        
                        <div class="box-title"><span><?php echo e($post ->title); ?></span></div>
                        <div class="price-box">
                        
                            <div class="price-new"> <abbr title="BRL">R$</abbr><span><?php echo e($post->price_new); ?></span>  </div>
                            <div class="price-from"> <abbr title="BRL">R$</abbr> <span><?php echo e($post->price_from); ?></span></div>
                    
                        </div>
                    
                        <p class="main-box-desc">
                        <?php echo e($post->description); ?>

                    
                        </p>
                    
                    </a> 

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        </div>

        </div>
 </div> 
 <script src="<?php echo e(asset('js/app.js')); ?>" ></script>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\judiostatic-laravel\resources\views/deals/index.blade.php ENDPATH**/ ?>