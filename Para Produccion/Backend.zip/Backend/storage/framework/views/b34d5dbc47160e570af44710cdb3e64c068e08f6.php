<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
<!-- Scripts -->
<script>
        window.default_locale = "<?php echo e(config('app.locale')); ?>";
        window.fallback_locale = "<?php echo e(config('app.fallback_locale')); ?>";
        window.messages = <?php echo json_encode($messages, 15, 512) ?>;
</script>

<section>
<div id="main-container" style="margin-top: 0px; min-height: 594px;">
    <div class="login-img" ></div>
     <div id='main-login-container'>



     <div id="main-login">   


            

                 <div id="app">
                     <login-form-component></login-form-component>
                 </div>

                



    </div>  
</div> 

</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.loginapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\judiostatic-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>