<?php

namespace judiostatic;

use Illuminate\Database\Eloquent\Model;

class AppAuthorized extends Model
{
    protected $table = 'AppAuthorized';
    protected $primaryKey = 'app_id';
}
