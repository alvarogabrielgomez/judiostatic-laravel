@extends('layouts.loginapp')

@section('content')
<section>
<div id="main-container" style="margin-top: 0px;">
    <div class="login-img" ></div>
     <div id='main-login-container'>



     <div id="main-login">   


            

                 <div id="app">
                     <login-form-component></login-form-component>
                 </div>

                



    </div>  
</div> 

</section>
@endsection

