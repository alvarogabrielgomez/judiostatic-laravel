<?php 
$hasAvatar = false;
if(Auth::check()){ //Logueado
$avatar = Auth::user()->avatar;
$hasAvatar = false;
if(strlen($avatar) > 5) { // Has Avatar
$hasAvatar = true;
}
}

//dd($hasAvatar);
?>


        
        <div class="dropdown">
                <button onclick="dropdownShow()" class="dropbtn">
                



                        <?php if(Auth::check()): ?>
                        
                        <?php if($hasAvatar == false): ?>
                        
                        <i class="dropbtn-i fas fa-user"></i>
                        <?php else: ?>
                        <div class="dropbtn-avatar">
                        <img src="<?php echo e(Auth::user()->avatar); ?>" alt="avatar">
                        </div>
                        <?php endif; ?>
                        
                        <span><?php echo e(Auth::user()->client_first); ?></span>
                        <?php else: ?>
                        <i class="dropbtn-i fas fa-user-ninja"></i>
                        <span>Ninjaman</span>
                        
                        <?php endif; ?>
                        
                        
                </button>

                
                <div id="dropdown-menu" class="dropdown-content">
                        <div id="whoisyou">
                                <div id="whoisyou-img"> 
                                        <?php if(Auth::check()): ?>
                                        <?php if($hasAvatar == false): ?>
                                        <i style="font-size: 1.35em;color: #666;display: block;margin: auto;width: 23px;height: 25px;" class="fas fa-user"></i>    
                                        <?php else: ?>
                                        <div class="dropbtn-avatar-drop">
                                        <img src="<?php echo e(Auth::user()->avatar); ?>" alt="avatar">
                                        </div>
                                        <?php endif; ?>
                                        <?php else: ?>
                                        <i style="font-size: 1.35em;color: #666;display: block;margin: auto;width: 23px;height: 25px;" class="fas fa-user-ninja"></i>
                                        <?php endif; ?>
                        </div> 
                                <div id="whoisyou-name">
                                        <?php if(Auth::check()): ?>
                                        <span><?php echo e(Auth::user()->client_first); ?></span>
                                        <?php else: ?>
                                        <span>Ninjaman</span>
                                        <?php endif; ?>
                                
                                <div id="whoisyou-email">
                                        <?php if(Auth::check()): ?>
                                        <span><?php echo e(Auth::user()->email); ?></span>
                                        <?php else: ?>
                                        <span>Anon</span>
                                        <?php endif; ?>  
                                </div>
                        </div>
                        </div>
                        <div id="dropdown-o-container">
                                <?php if(Auth::check()): ?>
                                <a href="/home">Dashboard</a>
                                <a><form action="/logout" method="POST">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="logout-b" name="logout-submit">Logout</button>
                                </form></a>
                                <?php else: ?>
                                <a href="/login">Iniciar Sesion</a>
                                <?php endif; ?>  
                                
                                <div class="divider"></div>
                                <a href="#footer">Ayuda</a>   
                        </div>
                </div> 
                
        </div>

        <?php /**PATH C:\Users\user\judiostatic-laravel\resources\views/partials/loginstatus.blade.php ENDPATH**/ ?>