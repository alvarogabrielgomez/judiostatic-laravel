
<?php $__env->startSection('loginstatus'); ?>

<script>
function dropdownShow() {
    document.getElementById("dropdown-menu").classList.toggle("show");
}
</script>


        <div class="dropdown">
                <button onclick="dropdownShow()" class="dropbtn">
                        <i style="font-size: 1.35em;color: #FFF;margin: 14px 0px;letter-spacing: 1px;" 
                        class="dropbtn-i VARIABLE "></i>
                        <?php if(Auth::check()): ?>
                        <span><?php echo e(Auth::user()->client_first); ?></span>
                        <?php else: ?>
                        <span>Not Logued</span>
                        <?php endif; ?>
                </button>
        </div>

        
<?php $__env->stopSection(); ?><?php /**PATH C:\Users\user\judiostatic-laravel\resources\views////partials/loginstatus.blade.php ENDPATH**/ ?>