<script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

<div id="app"> 
<dealsubmit-component postdata="<?php echo e($posts); ?>" descuento="<?php echo e(abs(round((($posts->price_new/$posts->price_from)*100)-100))); ?>" userdata="<?php echo e($userdata); ?>">
    </dealsubmit-component>
</div>


<?php /**PATH C:\Users\user\judiostatic-laravel\resources\views/partials/modalwindow/continue.blade.php ENDPATH**/ ?>