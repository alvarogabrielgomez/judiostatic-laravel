<template>
    <button type="button" class="btn btn-primary top-space" 
    data-toggle="modal" data-target="#addPokemon">
    Agregar
    </button>
</template>
<script>
export default {
    
}
</script>

<style>
.top-space{
    margin-top:20px
}
</style>
