@extends('layouts.app')
@section('content')
    <create-pokemon-form></create-pokemon-form>
    <add-pokemon-btn></add-pokemon-btn>
    <pokemons-component></pokemons-component>
@endsection