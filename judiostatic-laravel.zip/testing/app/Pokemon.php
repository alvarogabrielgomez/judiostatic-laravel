<?php

namespace judiostatic;

use Illuminate\Database\Eloquent\Model;

class Pokemon extends Model
{
    //
}
