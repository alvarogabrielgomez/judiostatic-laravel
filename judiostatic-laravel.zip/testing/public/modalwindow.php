<!-- The Modal -->


<div id="modalwindow" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <div class="modal-header">
      <span class="close">&times;</span>
      <h2 class = "titulomodal">Complete o pedido</h2>
    </div>
    <div class="modal-body">
  <!-- AJAX content -->
    </div>
    <div class="modal-footer">
        
    <div id="creditos"><div><a href="documents/terms.html">Condições de Uso</a> <a href="documents/privacy-policy.html">Privacidade</a><a href="https://ckj.one"> © Alvaro Gabriel Gomez</a>. <span id="rights">TODOS OS DIREITOS RESERVADOS</span></div></div>

    </div>
  </div>

</div>
